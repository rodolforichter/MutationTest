``` ini

BenchmarkDotNet=v0.12.1, OS=Windows 10.0.19042
Intel Core i7-10510U CPU 1.80GHz, 1 CPU, 8 logical and 4 physical cores
.NET Core SDK=5.0.103
  [Host] : .NET Core 5.0.3 (CoreCLR 5.0.321.7212, CoreFX 5.0.321.7212), X64 RyuJIT


```
|  Method | Mean | Error | Rank |
|-------- |-----:|------:|-----:|
| DoWhile |   NA |    NA |    ? |
|   DoFor |   NA |    NA |    ? |

Benchmarks with issues:
  LoopBenchmark.DoWhile: DefaultJob
  LoopBenchmark.DoFor: DefaultJob
