﻿namespace ClassLibrary.NET5
{
    public record PersonRecord(string Name, int Age);
}
