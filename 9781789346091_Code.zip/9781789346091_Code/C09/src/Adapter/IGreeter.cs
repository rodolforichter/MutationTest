﻿namespace Adapter
{
    public interface IGreeter
    {
        string Greeting();
    }
}
