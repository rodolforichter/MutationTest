﻿namespace OpaqueFacadeSubSystem
{
    internal class ComponentA
    {
        public string OperationA() => "Component A, Operation A";
        public string OperationB() => "Component A, Operation B";
    }
}
