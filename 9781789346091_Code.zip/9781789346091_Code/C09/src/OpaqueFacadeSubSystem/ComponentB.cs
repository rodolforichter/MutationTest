﻿namespace OpaqueFacadeSubSystem
{
    internal class ComponentB
    {
        public string OperationC() => "Component B, Operation C";
        public string OperationD() => "Component B, Operation D";
    }
}
