﻿namespace TransparentFacadeSubSystem.Abstractions
{
    public interface IComponentB
    {
        string OperationC();
        string OperationD();
    }
}