﻿namespace DecoratorScrutor
{
    public interface IComponent
    {
        string Operation();
    }
}
