﻿namespace DecoratorScrutor
{
    public class ComponentA : IComponent
    {
        public string Operation()
        {
            return "Hello from ComponentA";
        }
    }
}
