namespace MVC.Models
{
    public class SomeModel
    {
        public string Title { get; set; }
        public int SelectedId { get; set; }
    }
}