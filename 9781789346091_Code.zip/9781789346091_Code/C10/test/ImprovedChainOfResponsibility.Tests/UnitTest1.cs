using System;
using Xunit;

namespace ImprovedChainOfResponsibility.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
