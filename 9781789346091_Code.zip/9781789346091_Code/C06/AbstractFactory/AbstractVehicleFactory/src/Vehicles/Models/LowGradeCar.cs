﻿namespace Vehicles.Models
{
    public class LowGradeCar : ICar { }
}
