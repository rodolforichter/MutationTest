﻿namespace OpenAPI.Models
{
    public enum WorkState
    {
        New,
        InProgress,
        Completed
    }
}
