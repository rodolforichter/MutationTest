﻿namespace My.Api.Contracts
{
    public enum WorkState
    {
        New,
        InProgress,
        Completed
    }
}
