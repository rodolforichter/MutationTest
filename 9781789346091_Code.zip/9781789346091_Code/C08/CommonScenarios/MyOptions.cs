﻿namespace CommonScenarios
{
    public class MyOptions
    {
        public string Name { get; set; }
    }
}
