﻿namespace ClearName
{
    public interface IExampleService
    {
        RandomResult RandomizeOneString();
    }
}
