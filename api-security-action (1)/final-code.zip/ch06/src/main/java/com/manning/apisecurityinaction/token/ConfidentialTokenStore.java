package com.manning.apisecurityinaction.token;

public interface ConfidentialTokenStore extends TokenStore {
}
