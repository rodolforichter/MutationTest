package com.manning.apisecurityinaction.token;

public interface AuthenticatedTokenStore extends TokenStore {
}
